package dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exceptions.NoCustomerInfoException;
import exceptions.NoTransactionInfoException;
import model.Customer;
import model.Transaction;
import resources.MyQueries;

public class CustomerDao extends dbconnection_abstract {

	public Customer getAccountInfo(int ssn) throws SQLException, NoCustomerInfoException, IOException {
		//returns a customer info given an SSN
		myconnection();
		ps = con.prepareStatement(MyQueries.checkCustomerAccount);
		ps.setInt(1, ssn);
		rs = ps.executeQuery();
		Customer c = new Customer();
		if (rs.next()) {
			//setting all fields from database in a customer object
			c.setFirstname(rs.getString(1));
			c.setMiddlename(rs.getString(2));
			c.setLastname(rs.getString(3));
			c.setSsn(rs.getInt(4));
			c.setCardNo(rs.getString(5));
			c.setApt(rs.getString(6));
			c.setStreet(rs.getString(7));
			c.setCity(rs.getString(8));
			c.setState(rs.getString(9));
			c.setCountry(rs.getString(10));
			c.setZip(rs.getString(11));
			c.setPhone(rs.getInt(12));
			c.setEmail(rs.getString(13));
			c.setLastupdate(rs.getTimestamp(14));
			return c;
		}
		throw new NoCustomerInfoException("No customer found");
	}

	public Customer updateCustomer(int ssn, String field, String value)
			throws SQLException, NoCustomerInfoException, IOException {
		//updates a customer info given an SSN for string type
		myconnection();
		String replaceField = MyQueries.modifyCustomerAccount.replace("FIELD", field);
		ps = con.prepareStatement(replaceField);
		ps.setString(1, value);
		ps.setInt(2, ssn);
		ps.executeUpdate();
		return getAccountInfo(ssn);

	}

	public Customer updateCustomer(int ssn, String field, int value)
			throws SQLException, NoCustomerInfoException, IOException {
		//updates a customer info given an SSN for numeric type
		myconnection();
		String replaceField = MyQueries.modifyCustomerAccount.replace("FIELD", field);
		ps = con.prepareStatement(replaceField);
		ps.setInt(1, value);
		ps.setInt(2, ssn);
		ps.executeUpdate();
		return getAccountInfo(ssn);
	}
	
	public List<Transaction> getMonthlyBill(int ssn, int month, int year)
			throws NoTransactionInfoException, IOException, SQLException {
		//returns a list of transactions for a given month
		myconnection();
		List<Transaction> tran = new ArrayList<Transaction>();
		ps = con.prepareStatement(MyQueries.monthlyBill);
		ps.setInt(1, ssn);
		ps.setInt(2, month);
		ps.setInt(3, year);
		rs = ps.executeQuery();

		while (rs.next()) {
			//setting all fields from database in a transaction object
			Transaction t = new Transaction();
			t.setId(rs.getInt(1));
			t.setDay(rs.getInt(2));
			t.setMonth(rs.getInt(3));
			t.setYear(rs.getInt(4));
			t.setCardNo(rs.getString(5));
			t.setSsn(rs.getInt(6));
			t.setBranchCode(rs.getInt(7));
			t.setType(rs.getString(8));
			t.setValue(rs.getFloat(9));
			tran.add(t);
		}
		if (tran.isEmpty()) {
			throw new NoTransactionInfoException("No transaction found");
		}
		return tran;
	}

	public List<Transaction> getBetweenTwoDates(int ssn, String[] datearray1, String[] datearray2)
			throws IOException, SQLException, NoTransactionInfoException {
		//returns a list of transactions between two different dates
		myconnection();
		List<Transaction> tran = new ArrayList<Transaction>();
		//takes month,day and year as strings variables
		String month1 = datearray1[0];
		String month2 = datearray2[0];
		String day1 = datearray1[1];
		String day2 = datearray2[1];
		String year1 = datearray1[2];
		String year2 = datearray2[2];

		ps = con.prepareStatement(MyQueries.transactionsBetweenTwoDates);
		ps.setInt(1, ssn);
		ps.setString(2, day1);
		ps.setString(3, month1);
		ps.setString(4, year1);
		ps.setString(5, day2);
		ps.setString(6, month2);
		ps.setString(7, year2);
		rs = ps.executeQuery();

		while (rs.next()) {

			Transaction t = new Transaction();
			t.setId(rs.getInt(1));
			t.setDay(rs.getInt(2));
			t.setMonth(rs.getInt(3));
			t.setYear(rs.getInt(4));
			t.setCardNo(rs.getString(5));
			t.setSsn(rs.getInt(6));
			t.setBranchCode(rs.getInt(7));
			t.setType(rs.getString(8));
			t.setValue(rs.getFloat(9));
			tran.add(t);
		}
		if (tran.isEmpty()) {
			throw new NoTransactionInfoException("No transaction found");
		}
		return tran;
	}

}