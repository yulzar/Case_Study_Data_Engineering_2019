package dao;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import exceptions.NoCustomerInfoException;
import exceptions.NoTransactionException;
import exceptions.NoTransactionInfoException;
import model.Transaction;
import resources.MyQueries;

public class TransactionDao extends dbconnection_abstract {

	public List<Transaction> getTransactionByZip(int zip, int month, int year)
			throws SQLException, NoTransactionInfoException, IOException {
		//returns a list of transactions info given zip, month, year
		myconnection();
		List<Transaction> tran = new ArrayList<Transaction>();
		ps = con.prepareStatement(MyQueries.transactionByZip);
		ps.setInt(1, zip);
		ps.setInt(2, month);
		ps.setInt(3, year);
		rs = ps.executeQuery();
		while (rs.next()) {

			Transaction t = new Transaction();
			t.setId(rs.getInt(1));
			t.setDay(rs.getInt(2));
			t.setMonth(rs.getInt(3));
			t.setYear(rs.getInt(4));
			t.setCardNo(rs.getString(5));
			t.setSsn(rs.getInt(6));
			t.setBranchCode(rs.getInt(7));
			t.setType(rs.getString(8));
			t.setValue(rs.getFloat(9));
			tran.add(t);
		}

		if (tran.isEmpty()) {
			throw new NoTransactionInfoException("No transaction found");
		}
		return tran;
	}

	public Transaction getTotalbyType(String type) throws IOException, SQLException, NoTransactionException {
		//returns the total value and count of transactions by type 
		myconnection();
		ps = con.prepareStatement(MyQueries.totalByType);
		ps.setString(1, type);
		rs = ps.executeQuery();
		Transaction t = new Transaction();
		if (rs.next()) {
			t.setValue(rs.getFloat(1));
			t.setCount(rs.getInt(2));
			return t;
		}

		throw new NoTransactionException("There is no transaction");
	}

	public Transaction getTotalByState(String state) throws NoTransactionException, IOException, SQLException {
		//returns the total value and count of transactions by given state 
		myconnection();
		ps = con.prepareStatement(MyQueries.totalByState);
		ps.setString(1, state);
		rs = ps.executeQuery();
		Transaction t = new Transaction();
		if (rs.next()) {
			t.setCount(rs.getInt(1));
			t.setValue(rs.getFloat(2));
			return t;
		}
		throw new NoTransactionException("There is no transaction");
	}

}