package dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public abstract class dbconnection_abstract {
	public Connection con = null;
	public ResultSet rs;
	public PreparedStatement ps;

	protected void myconnection() throws IOException, SQLException {
		// step 1
		FileReader f = new FileReader("db.properties");
		// will hold properties of f
		Properties p = new Properties();
		// p loads properties
		p.load(f);
		// step 2
		con = DriverManager.getConnection(p.getProperty("url"), p.getProperty("username"), p.getProperty("password"));
	}
}
