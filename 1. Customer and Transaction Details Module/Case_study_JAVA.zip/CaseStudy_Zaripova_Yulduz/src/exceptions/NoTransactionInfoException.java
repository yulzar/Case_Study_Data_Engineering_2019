package exceptions;

public class NoTransactionInfoException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoTransactionInfoException() {
		super();
	}

	public NoTransactionInfoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NoTransactionInfoException(String message, Throwable cause) {
		super(message, cause);
	}

	public NoTransactionInfoException(String message) {
		super(message);
	}

	public NoTransactionInfoException(Throwable cause) {
		super(cause);
	}

}
