package resources;

public class MyQueries {
	public final static String transactionByZip = "SELECT * "
			+ "FROM cdw_sapp_creditcard cc join cdw_sapp_customer cus ON cc.credit_card_no = cus.credit_card_no "
			+ "WHERE cust_zip = ? and month = ? and year = ? " + "ORDER BY day DESC";

	public final static String totalByType = "SELECT sum(transaction_value), count(*) " + "FROM CDW_SAPP_CREDITCARD "
			+ "WHERE  TRANSACTION_TYPE = ? " + "GROUP BY TRANSACTION_TYPE";

	public final static String totalByState = "SELECT count(transaction_id), sum(transaction_value), branch_state "
			+ "FROM cdw_sapp_creditcard cc " + "JOIN cdw_sapp_branch b ON cc.branch_code = b.branch_code "
			+ "WHERE branch_state = ?";

	public final static String checkCustomerAccount = "SELECT * " + "FROM cdw_sapp_customer " + "WHERE ssn = ? ";

	public final static String modifyCustomerAccount = "UPDATE cdw_sapp_customer " + "SET FIELD = ? " + "WHERE ssn = ?";

	public final static String monthlyBill = "SELECT * " + "FROM cdw_sapp_creditcard "
			+ "WHERE cust_ssn = ? AND month = ? AND year = ?";

	public final static String transactionsBetweenTwoDates = "SELECT * " + "FROM cdw_sapp_creditcard "
			+ "WHERE cust_ssn = ? and str_to_date(concat(day,'/', month,'/', year),'%d/%m/%y') "
			+ "BETWEEN str_to_date(concat(?,'/', ?,'/', ?), '%d/%m/%y') and str_to_date(concat(?,'/', ?,'/', ?), '%d/%m/%y') "
			+ "ORDER BY  year, month, day DESC";
}
