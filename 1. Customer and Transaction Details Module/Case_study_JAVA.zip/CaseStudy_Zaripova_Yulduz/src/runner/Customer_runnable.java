package runner;

import java.io.IOException;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import dao.CustomerDao;
import exceptions.NoCustomerInfoException;
import exceptions.NoTransactionInfoException;
import model.Customer;
import model.Transaction;

public class Customer_runnable {

	public void getAccountInfo() throws SQLException, NoCustomerInfoException, IOException {
		// prompts for SSN and prints out customer info

		Scanner sc = new Scanner(System.in);
		int ssn = 0;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter social security number: ");
				ssn = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}

		CustomerDao cd = new CustomerDao();
		Customer custinfo = cd.getAccountInfo(ssn);

		System.out.println("First name: " + custinfo.getFirstname());
		System.out.println("Middle name: " + custinfo.getMiddlename());
		System.out.println("Last name: " + custinfo.getLastname());
		System.out.println("SSN: " + custinfo.getSsn());
		System.out.println("CardNo: " + custinfo.getCardNo());
		System.out.println("Apt: " + custinfo.getApt());
		System.out.println("Street: " + custinfo.getStreet());
		System.out.println("City: " + custinfo.getCity());
		System.out.println("State: " + custinfo.getState());
		System.out.println("Country: " + custinfo.getCountry());
		System.out.println("Zip: " + custinfo.getZip());
		System.out.println("Phone: " + custinfo.getPhone());
		System.out.println("Email: " + custinfo.getEmail());
		System.out.println("Last Updated: " + custinfo.getLastupdate());
	}

	public void updateCustomer() throws SQLException, NoCustomerInfoException, IOException {
		// prompts for SSN, updates and prints out customer info
		Scanner sc = new Scanner(System.in);
		int ssn = 0;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter social security number: ");
				ssn = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}

		Customer_runnable c = new Customer_runnable();
		int choice = 0;
		String field;
		while (choice != 14) {
			menu();
			choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 1:
				field = "FIRST_NAME";
				break;
			case 2:
				field = "MIDDLE_NAME";
				break;
			case 3:
				field = "LAST_NAME";
				break;
			case 4:
				field = "SSN";
				break;
			case 5:
				field = "CREDIT_CARD_NO";
				break;
			case 6:
				field = "APT_NO";
				break;
			case 7:
				field = "STREET_NAME";
				break;
			case 8:
				field = "CUST_CITY";
				break;
			case 9:
				field = "CUST_STATE";
				break;
			case 10:
				field = "CUST_COUNTRY";
				break;
			case 11:
				field = "CUST_ZIP";
				break;
			case 12:
				field = "CUST_PHONE";
				break;
			case 13:
				field = "CUST_EMAIL";
				break;
			case 14:
				System.out.println("Exiting... :)");
				return;
			default:
				return;
			}

			CustomerDao cd = new CustomerDao();
			Customer custinfo;
			if (choice == 12) {
				int value = 0;
				success = false;
				while (!success) {
					try {
						System.out.println("Please enter Value: ");
						value = sc.nextInt();
						success = true;
					} catch (InputMismatchException e) {
						System.out.println("Wrong input. Try again.");
						sc.nextLine();
						success = false;
					}
				}
				custinfo = cd.updateCustomer(ssn, field, value);
			} else {

				String value = null;
				success = false;
				while (!success) {
					try {
						System.out.println("Please enter Value: ");
						value = sc.nextLine();
						success = true;
					} catch (InputMismatchException e) {
						System.out.println("Wrong input. Try again.");
						sc.nextLine();
						success = false;
					}
				}
				custinfo = cd.updateCustomer(ssn, field, value);
			}
			System.out.println("\nModified Information:");

			System.out.println("First name: " + custinfo.getFirstname());
			System.out.println("Middle name: " + custinfo.getMiddlename());
			System.out.println("Last name: " + custinfo.getLastname());
			System.out.println("SSN: " + custinfo.getSsn());
			System.out.println("CardNo: " + custinfo.getCardNo());
			System.out.println("Apt: " + custinfo.getApt());
			System.out.println("Street: " + custinfo.getStreet());
			System.out.println("City: " + custinfo.getCity());
			System.out.println("State: " + custinfo.getState());
			System.out.println("Country: " + custinfo.getCountry());
			System.out.println("Zip: " + custinfo.getZip());
			System.out.println("Phone: " + custinfo.getPhone());
			System.out.println("Email: " + custinfo.getEmail());
			System.out.println("Last Updated: " + custinfo.getLastupdate());

			System.out.println("\nUpdate Successful!!!:");
			System.out.println("\nPress enter to continue:");
			try {
				System.in.read();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

//prints out menu for updated customer method
	public static void menu() {
		System.out.println("\n**Available Fields**");
		System.out.println("1. First Name ");
		System.out.println("2. Middle Name ");
		System.out.println("3. Last Name ");
		System.out.println("4. Social Security Number ");
		System.out.println("5. Card Number ");
		System.out.println("6. Number of Apartment ");
		System.out.println("7. Name of the Street: ");
		System.out.println("8. City ");
		System.out.println("9. State ");
		System.out.println("10. Country ");
		System.out.println("11. Zipcode ");
		System.out.println("12. Phone Number ");
		System.out.println("13. Email ");
		System.out.println("14. Exit ");

	}

	public void getMonthlyBill() throws SQLException, IOException, NoTransactionInfoException {
    //prompts a list of transactions for a given SSN, month and year
		Scanner sc = new Scanner(System.in);
		int ssn = 0;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter social security number: ");
				ssn = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		int month = 0;
		success = false;
		while (!success) {
			try {
				System.out.println("Please enter month: ");
				month = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		int year = 0;
		success = false;
		while (!success) {
			try {
				System.out.println("Please enter year: ");
				year = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		CustomerDao cd = new CustomerDao();
		List<Transaction> tran = cd.getMonthlyBill(ssn, month, year);
		System.out.printf("%-10s%-7s%-7s%-10s%-20s%-10s%-10s%-20s%-10s\n", "Trans_ID", "Day", "Month", "Year",
				"Credit_Card_No", "SSN", "Branch", "Type", "Value");

		for (int i = 0; i < tran.size(); i++) {
			Transaction t = tran.get(i);
			System.out.printf("%-10d%-7d%-7d%-10d%-20s%-10d%-10d%-20s%-10.2f\n", t.getId(), t.getDay(), t.getMonth(),
					t.getYear(), t.getCardNo(), t.getSsn(), t.getBranchCode(), t.getType(), t.getValue());
		}
	}

	public void getBetweenTwoDates() throws SQLException, IOException, NoTransactionInfoException {
		//prompts SSN and two dates and prints out a list of transactions
		Scanner sc = new Scanner(System.in);
		int ssn = 0;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter social security number: ");
				ssn = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		String dateone = null;
		success = false;
		String[] datearray1 = new String[3];
		while (!success) {
			try {
				System.out.println("Please enter start date (mm/dd/yyyy):");
				String dataone = sc.next();
				datearray1 = dateone.split("/");
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		String datetwo = null;
		String[] datearray2 = new String[3];
		success = false;
		while (!success) {
			try {
				System.out.println("Please enter end date (mm/dd/yyyy):");
				String datatwo = sc.next();
				datearray2 = datetwo.split("/");
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}

		CustomerDao cd = new CustomerDao();
		List<Transaction> mytransaction = cd.getBetweenTwoDates(ssn, datearray1, datearray2);
		System.out.printf("%-10s%-7s%-7s%-10s%-20s%-10s%-15s%-20s%-10s\n", "Trans_ID", "Day", "Month", "Year",
				"Credit_Card_No", "SSN", "Branch", "Type", "Value");
		for (int i = 0; i < mytransaction.size(); i++) {
			Transaction t = mytransaction.get(i);
			System.out.printf("%-10d%-7d%-7d%-10d%-20s%-10d%-15d%-20s%-10.2f\n", t.getId(), t.getDay(), t.getMonth(),
					t.getYear(), t.getCardNo(), t.getSsn(), t.getBranchCode(), t.getType(), t.getValue());
		}
	}
}
