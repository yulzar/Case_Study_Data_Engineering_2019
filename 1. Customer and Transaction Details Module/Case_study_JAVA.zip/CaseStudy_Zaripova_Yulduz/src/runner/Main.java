package runner;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import exceptions.NoCustomerInfoException;
import exceptions.NoTransactionException;
import exceptions.NoTransactionInfoException;

public class Main {
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		Integer choice = 0;
		Customer_runnable c = new Customer_runnable();
		Transaction_runnable t = new Transaction_runnable();
		while (choice != 8) {
			//displays menu of available options
			menu();
			choice = reader.nextInt();
			reader.nextLine();
			switch (choice) {
			case 1:
				try {
					t.getTransactionByZip();
				} catch (SQLException | NoTransactionInfoException | IOException e4) {
					System.out.println("Error. Try again.");
				}
				break;
			case 2:
				try {
					t.getTotalByType();
				} catch (IOException | SQLException | NoTransactionException e2) {

					System.out.println("Error. Try again.");
				}
				break;
			case 3:

				try {
					t.getTotalByState();
				} catch (NoTransactionException | IOException | SQLException e3) {
					System.out.println("Error. Try again.");
				}

				break;
			case 4:

				try {
					c.getAccountInfo();
				} catch (SQLException | NoCustomerInfoException | IOException e2) {
					System.out.println("Error. Try again.");
				}
				break;
			case 5:
				try {
					c.updateCustomer();
				} catch (SQLException | NoCustomerInfoException | IOException e2) {
					System.out.println("Error. Try again.");
				}
				break;
			case 6:

				try {
					c.getMonthlyBill();
				} catch (SQLException | IOException | NoTransactionInfoException e2) {
					System.out.println("Error. Try again.");
				}
				break;
			case 7:
				try {
					c.getBetweenTwoDates();
				} catch (SQLException | IOException | NoTransactionInfoException e1) {
					System.out.println("Error. Try again.");
				}
				break;
			case 8:
				System.out.println("Exiting... :)");
				System.exit(0);
			}
			System.out.println("\nPress enter to continue:");
			try {
				System.in.read();
			} catch (IOException e) {
				System.out.println("Error. Try again.");
			}
		}
		reader.close();
	}

	public static void menu() {

		System.out.println("\n**Available Options**");
		System.out.println("1. Display the transactions made by customers living in a "
				+ "given zipcode for a given month and year");
		System.out.println("2. Display the total number and total values of transactions for a given type");
		System.out.println(
				"3. Display the total number and total values of transactions for " + "branches in a given state");
		System.out.println("4. Display the existing account details of a customer");
		System.out.println("5. Modify the existing account details of a customer");
		System.out.println("6. Display the monthly bill for a given month and year");
		System.out.println("7. Display the transactions made by a customer between two dates");
		System.out.println("8. Exit");
		System.out.println("Please choose one of the options above:");

	}
}
