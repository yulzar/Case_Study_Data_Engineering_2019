package runner;

import java.util.List;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import dao.TransactionDao;
import exceptions.NoTransactionException;
import exceptions.NoTransactionInfoException;
import model.Transaction;

public class Transaction_runnable {

	public void getTransactionByZip() throws SQLException, NoTransactionInfoException, IOException {
		//prompts for a zip code, month and  year and prints out a value and the count of transactions 
		Scanner sc = new Scanner(System.in);
		int zip = 0;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter zip code: ");
				zip = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		int month = 0;
		success = false;
		while (!success) {
			try {
				System.out.println("Please enter month: ");
				month = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}

		int year = 0;
		success = false;
		while (!success) {
			try {
				System.out.println("Please enter year: ");
				year = sc.nextInt();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}

		TransactionDao td = new TransactionDao();
		List<Transaction> tran = td.getTransactionByZip(zip, month, year);
		System.out.printf("%-10s%-7s%-7s%-10s%-20s%-10s%-10s%-20s%-10s\n", "Trans_ID", "Day", "Month", "Year",
				"Credit_Card_No", "SSN", "Branch", "Type", "Value");
		for (int i = 0; i < tran.size(); i++) {
			Transaction t = tran.get(i);
			System.out.printf("%-10d%-7d%-7d%-10d%-20s%-10d%-10d%-20s%-10.2f\n", t.getId(), t.getDay(), t.getMonth(),
					t.getYear(), t.getCardNo(), t.getSsn(), t.getBranchCode(), t.getType(), t.getValue());
		}
	}

	public void getTotalByType() throws IOException, SQLException, NoTransactionException {
		//prompts for transaction type and prints out a value and the count of transactions
			Scanner sc = new Scanner(System.in);
		String type = null;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter transaction Type:");
				type = sc.nextLine();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}
		TransactionDao td = new TransactionDao();
		Transaction mytransaction = td.getTotalbyType(type);
		System.out.println("Total number of transactions: " + mytransaction.getCount());
		System.out.println("Total values of transactions: " + mytransaction.getValue());

	}

	public void getTotalByState() throws NoTransactionException, IOException, SQLException {
		//prompts for a state and prints out a value and the count of transactions
		Scanner sc = new Scanner(System.in);
		String state = null;
		boolean success = false;
		while (!success) {
			try {
				System.out.println("Please enter State:");
				state = sc.nextLine();
				success = true;
			} catch (InputMismatchException e) {
				System.out.println("Wrong input. Try again.");
				sc.nextLine();
				success = false;
			}
		}

		TransactionDao td = new TransactionDao();
		Transaction mytransaction = td.getTotalByState(state);
		System.out.println("Total number of transactions: " + mytransaction.getCount());
		System.out.println("Total values of transactions: " + mytransaction.getValue());
	}
}
